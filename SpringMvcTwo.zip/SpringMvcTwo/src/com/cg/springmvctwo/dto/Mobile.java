package com.cg.springmvctwo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="MOBILEDATA")
public class Mobile {
	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mobid")
    @SequenceGenerator(name="mobid",sequenceName="mob_seq_id")
    @Column(name="mob_id")
	private Integer mobileID;
	
	   @Column(name="mob_name")
	private String mobileName;
	   @Column(name="mob_brand")
	private String mobileBrand;
	   @Column(name="mob_price")
	private double mobilePrice;
	   @Column(name="mob_online")
	private String mobileOnline;
	public Integer getMobileID() {
		return mobileID;
	}
	public void setMobileID(Integer mobileID) {
		this.mobileID = mobileID;
	}
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public String getMobileBrand() {
		return mobileBrand;
	}
	public void setMobileBrand(String mobileBrand) {
		this.mobileBrand = mobileBrand;
	}
	public double getMobilePrice() {
		return mobilePrice;
	}
	public void setMobilePrice(double mobilePrice) {
		this.mobilePrice = mobilePrice;
	}
	public String getMobileOnline() {
		return mobileOnline;
	}
	public void setMobileOnline(String mobileOnline) {
		this.mobileOnline = mobileOnline;
	}
	@Override
	public String toString() {
		return "Mobile [mobileID=" + mobileID + ", mobileName=" + mobileName
				+ ", mobileBrand=" + mobileBrand + ", mobilePrice="
				+ mobilePrice + ", mobileOnline=" + mobileOnline + "]";
	}
}