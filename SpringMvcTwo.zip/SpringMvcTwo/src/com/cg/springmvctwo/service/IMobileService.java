package com.cg.springmvctwo.service;

import java.util.List;

import com.cg.springmvctwo.dto.Mobile;

public interface IMobileService {
	public int insertData(Mobile mob);
	public List<Mobile> ShowData();
	public void removeData(int mobId);
    public List<Mobile> searchData(int mobId);
	

}
