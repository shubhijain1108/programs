package com.cg.springmvctwo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.cg.springmvctwo.dto.Mobile;
@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao{
	
	@PersistenceContext
	EntityManager entityManager;
	

	@Override
	public int insertData(Mobile mob) {
		// TODO Auto-generated method stub
		entityManager.persist(mob);
		entityManager.flush();
		return mob.getMobileID();
	}

	@Override
	public List<Mobile> ShowData() {
		// TODO Auto-generated method stub
		Query queryOne=entityManager.createQuery("FROM Mobile");  //Mobile is the name of dto class not sql table
		List<Mobile> dataList=queryOne.getResultList();
		return dataList;
	}
		

	@Override
	public void removeData(int mobId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Mobile> searchData(int mobId) {
		// TODO Auto-generated method stub
		Query queryTwo=entityManager.createQuery("FROM Mobile "+ "WHERE mobileID=:mob_id");
		queryTwo.setParameter("mob_id",mobId);
		List<Mobile> mySearch= queryTwo.getResultList();
		return mySearch;
		
	}

}
