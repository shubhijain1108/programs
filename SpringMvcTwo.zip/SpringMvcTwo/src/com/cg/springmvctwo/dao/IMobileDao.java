package com.cg.springmvctwo.dao;

import java.util.List;

import com.cg.springmvctwo.dto.Mobile;

public interface IMobileDao {
	public int insertData(Mobile mob);
	public List<Mobile> ShowData();
	public void removeData(int mobId);
    public List<Mobile> searchData(int mobId);

}
