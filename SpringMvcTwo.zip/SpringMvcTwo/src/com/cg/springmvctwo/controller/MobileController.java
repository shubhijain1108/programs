package com.cg.springmvctwo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.cg.springmvctwo.dto.Mobile;
import com.cg.springmvctwo.service.IMobileService;


@Controller
public class MobileController {
	
	@Autowired
	IMobileService mobileservice;

	//ADD
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my")Mobile mob,Map<String,Object>model)
	{
		List<String> myList=new ArrayList<String>();
		myList.add("Apple");
		myList.add("Samsung");
		myList.add("MI");
		myList.add("Nokia");
		myList.add("Motorola");
		
		
		model.put("mtype", myList);
		return "addMobile";
		
	
}
@RequestMapping(value="putdata",method=RequestMethod.POST)
public  ModelAndView dataAdd(@ModelAttribute("my") Mobile mob)
{
int mobId=mobileservice.insertData(mob);
	return new ModelAndView("success", "mob", mobId);

}

//SHOW
@RequestMapping(value="showall",method=RequestMethod.GET)
public ModelAndView dataShow()
{ List<Mobile> allData=mobileservice.ShowData();
	return new  ModelAndView("mobshow","mob",allData);
}


//SEARCH
@RequestMapping(value="search",method=RequestMethod.GET)
public String searchPage(@ModelAttribute("data") Mobile mSearch)
{
	return "mobsearch";
	
}
@RequestMapping(value="searchdata",method=RequestMethod.POST)
public ModelAndView searchData(@ModelAttribute("data")Mobile mData)

{//System.out.println(pData.getMobileID());
	int mobId=mData.getMobileID();
	 List<Mobile> searchData=mobileservice.searchData(mobId);
	return new  ModelAndView("mobshow","mob",searchData);
}

}