package com.cg.springmvcthree.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcthree.dao.IMobileDao;
import com.cg.springmvcthree.dto.Mobile;
import com.cg.springmvcthree.service.IMobileService;

@Controller
public class MobileController {
	@Autowired
	IMobileService mobileservice;
	
	//REMOVE
@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView getMobileDetail()
	{
	List<Mobile> showData=mobileservice.showAll();
	//System.out.println(showData);
	return new ModelAndView("mobileshow","mob",showData);
		
	}
@RequestMapping(value="delete",method=RequestMethod.GET)
public String deleteMobile(@RequestParam("id")int mobId){
	//System.out.println(mobId);
	 mobileservice.removeMobile(mobId);
	return "redirect:/show";
	
}

//UPDATE
@RequestMapping(value="update",method = RequestMethod.GET )
public ModelAndView update(@RequestParam("id") int id ,Map<String,Object> model ,Map<String, Object> model1, @ModelAttribute("my")Mobile mob)

{
		List<String> myList=new ArrayList<String>();
		myList.add("MOTOROLA");
		myList.add("SAMSUNG");
		myList.add("NOKIA");
		model1.put("mtype", myList);
	
	 mob = mobileservice.searchMobile(id);
	
	System.out.println("In controller "+mob);
	model.put("my",mob);
	return new ModelAndView("mobileUpdateList") ;
	
}

@RequestMapping(value = "putdata" , method = RequestMethod.POST)
public String updateData(@ModelAttribute("my")Mobile mob)
{
	mobileservice.updateMobile(mob);
	return "redirect:/show";
	
}


}
