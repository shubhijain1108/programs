package com.cg.springmvcthree.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.cg.springmvcthree.dao.IMobileDao;
import com.cg.springmvcthree.dto.Mobile;
@Service("mobservice")
@Transactional
public class MobileServiceImpl implements IMobileService{

	@Autowired
	IMobileDao mobiledao;
	@Override
	public List<Mobile> showAll() {
		// TODO Auto-generated method stub
		return mobiledao.showAll();
	}

	@Override
	public void removeMobile(int mobileId) {
		// TODO Auto-generated method stub
		mobiledao.removeMobile(mobileId);
	}

	
	@Override
	public void updateMobile(Mobile mob) {
		mobiledao.updateMobile(mob);
		
	}

	@Override
	public Mobile searchMobile(int MobileId) {
		// TODO Auto-generated method stub
		return mobiledao.searchMobile(MobileId);
	}
}
