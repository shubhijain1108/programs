package com.cg.springmvcthree.service;

import java.util.List;

import com.cg.springmvcthree.dto.Mobile;

public interface IMobileService {
	
	public List<Mobile> showAll();
	public void removeMobile(int mobileId);
	public void updateMobile(Mobile mob);
	Mobile searchMobile(int MobileId);
}
