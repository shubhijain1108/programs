package com.cg.springmvcthree.dao;

import java.util.List;

import com.cg.springmvcthree.dto.Mobile;

public interface IMobileDao {

	public List<Mobile> showAll();
	public void removeMobile(int mobileId);
	public void updateMobile(Mobile mob);
	Mobile searchMobile(int mobileId);
}
