package com.cg.springmvcthree.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcthree.dto.Mobile;

@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao{
    @PersistenceContext
    EntityManager  entityManager;
	@Override
	public List<Mobile> showAll() {
		// TODO Auto-generated method stub
		
		Query queryOne=entityManager.createQuery("FROM Mobile");  //Mobile is the name of dto class not sql table
		List<Mobile> allData=queryOne.getResultList();
		return allData;
	}
		
	@Override
	public void removeMobile(int mobileId) {
		// TODO Auto-generated method stub
		Query queryTwo=entityManager.createQuery("DELETE FROM Mobile WHERE mobileId=:mob_id"); 
		queryTwo.setParameter("mob_id", mobileId);
		queryTwo.executeUpdate();
	}


		
	
	@Override
	public void updateMobile(Mobile mob) {
		Query queryTwo = entityManager.createQuery("Update Mobile SET mobileName = :mob_name , mobilePrice = :mob_price , mobileBrand = :mob_brand where mobileId = :mob_id");
	    queryTwo.setParameter("mob_id", mob.getMobileId());
	    queryTwo.setParameter("mob_name", mob.getMobileName());
	    queryTwo.setParameter("mob_brand", mob.getMobileBrand());
	    queryTwo.setParameter("mob_price", mob.getMobilePrice());
	    queryTwo.executeUpdate();
	    
	
	}


	@Override
	public Mobile searchMobile(int mobileId) {
		Query querOne = entityManager.createQuery("From Mobile where mobileId = :mobile_id");
		querOne.setParameter("mobile_id", mobileId);
		Mobile mobList =(Mobile)querOne.getSingleResult();
		System.out.println(mobList);
			return mobList;
	}

}
