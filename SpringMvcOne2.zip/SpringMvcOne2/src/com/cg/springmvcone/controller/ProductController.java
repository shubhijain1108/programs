package com.cg.springmvcone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcone.dto.Product;
import com.cg.springmvcone.service.IProductService;


@Controller
public class ProductController {

	@Autowired
	IProductService productservice;
	
	//ADD
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addData(@ModelAttribute("my")Product pro,Map<String,Object>model)
	{
		List<String> myList=new ArrayList<String>();
		myList.add("Electronics");
		myList.add("Grocery");
		myList.add("Home-Appliances");
		
		model.put("ptype", myList);
		return "addProduct";
		
	}
@RequestMapping(value="putdata",method=RequestMethod.POST)
	public ModelAndView dataAdd(@Valid@ModelAttribute("my") Product pro,BindingResult error,Map<String,Object>model)
	{
	if(error.hasErrors()){
		List<String> myList=new ArrayList<String>();
		myList.add("Electronics");
		myList.add("Grocery");
		myList.add("Home-Appliances");
		
		model.put("ptype", myList);
		return new ModelAndView("addProduct");
	}else{
	int prodId=productservice.insertData(pro);
		return new ModelAndView("success", "pro", prodId);
	}	
	}

//SHOW
@RequestMapping(value="showall",method=RequestMethod.GET)
public ModelAndView dataShow()
{ List<Product> allData=productservice.ShowData();
	return new  ModelAndView("prodshow","mydata",allData);
}


//SEARCH
@RequestMapping(value="search",method=RequestMethod.GET)
public String searchPage(@ModelAttribute("data") Product pSearch)
{
	return "prodsearch";
	
}
@RequestMapping(value="searchdata",method=RequestMethod.POST)
public ModelAndView searchData(@ModelAttribute("data") Product pData)

{//System.out.println(pData.getProductID());
	int prodId=pData.getProductID();
	 List<Product> searchData=productservice.searchData(prodId);
	return new  ModelAndView("prodshow","mydata",searchData);
}
//Remove
	@RequestMapping(value="remove", method=RequestMethod.GET)
	public String removePage(@ModelAttribute("Data") Product pRemove)
	{
		return "prodremove";
		
	}
	
	@RequestMapping(value="removeProd", method=RequestMethod.POST)
	public ModelAndView removeProd(@ModelAttribute("Data") Product rData)
	{
		int prodId= rData.getProductID();
		productservice.removeData(prodId);
		
		return new ModelAndView("proremove");
		
	}




	}


