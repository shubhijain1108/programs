package com.cg.springmvcone.service;

import java.util.List;


import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcone.dao.IProductDao;
import com.cg.springmvcone.dto.Product;


@Service("productservice")
@Transactional
public class ProductServiceImpl implements IProductService {
    @Autowired
    IProductDao productdao;
	@Override
	public int insertData(Product prod) {
		// TODO Auto-generated method stub
		return productdao.insertData(prod);
	}

	@Override
	public List<Product> ShowData() {
		// TODO Auto-generated method stub
		return productdao.ShowData();
	}

	@Override
	public void removeData(int prodId) {
		productdao.removeData(prodId);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Product> searchData(int prodId) {
		// TODO Auto-generated method stub
		
		return productdao.searchData(prodId);
	}

	
}
