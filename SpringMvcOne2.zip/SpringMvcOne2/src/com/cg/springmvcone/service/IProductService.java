
package com.cg.springmvcone.service;

import java.util.List;

import com.cg.springmvcone.dto.Product;


public interface IProductService {
	public int insertData(Product prod);
	public List<Product> ShowData();
	public void removeData(int prodId);
    public List<Product> searchData(int prodId);
}
