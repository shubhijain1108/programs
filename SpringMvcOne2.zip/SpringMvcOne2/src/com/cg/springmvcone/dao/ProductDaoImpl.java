package com.cg.springmvcone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcone.dto.Product;

@Repository("productdao")
public class ProductDaoImpl implements IProductDao{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public int insertData(Product prod) {
		// TODO Auto-generated method stub
		
		entityManager.persist(prod);
		entityManager.flush();
		return prod.getProductID();
	}

	@Override
	public List<Product> ShowData() {
		// TODO Auto-generated method stub
		Query  queryOne=entityManager.createQuery("FROM Product");  //product is the name of dto class not sql table
		List<Product> dataList=	 queryOne.getResultList();
		return dataList;
	}

	@Override
	public void removeData(int prodId) {
			
			Query queryThree = entityManager.createQuery("DELETE FROM Product WHERE productID=:prod_id");
			System.out.println("Dummy");
			queryThree.setParameter("prod_id", prodId);
			queryThree.executeUpdate();
		
		
		
	}

	@Override
	public List<Product> searchData(int prodId) {
		// TODO Auto-generated method stub
		Query queryTwo=entityManager.createQuery("FROM Product "+ "WHERE productID=:prod_id");
		queryTwo.setParameter("prod_id",prodId);
		List<Product> mySearch= queryTwo.getResultList();
		return mySearch;
	}

}
