package com.cg.springmvcone.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="PRODUCTDATA")
public class Product {
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE,generator="prodid")
    @SequenceGenerator(name="prodid",sequenceName="prod_seq_id")
    @Column(name="prod_id")
    private Integer productID;
    
    @Column(name="prod_name")
    @NotEmpty(message="Product Name required")
    @Size(min=3,max=20,message="")
    @Pattern(regexp="^[A-Z][a-z]+$")
	private String productName;
    @Column(name="prod_type")
	private String productType;
    @Column(name="prod_price")
    @NotNull(message="Price is required")
	private Double productPrice;
    @Column(name="prod_online")
    @NotEmpty(message="Online is required")
	private String productOnline;
	
	public Integer getProductID() {
		return productID;
	}
	public void setProductID(Integer productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public Double getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}
	public String getProductOnline() {
		return productOnline;
	}
	public void setProductOnline(String productOnline) {
		this.productOnline = productOnline;
	}
	@Override
	public String toString() {
		return "Prodcut [productID=" + productID + ", productName="
				+ productName + ", productType=" + productType
				+ ", productPrice=" + productPrice + ", productOnline="
				+ productOnline + "]";
	}
	
	
	
}
