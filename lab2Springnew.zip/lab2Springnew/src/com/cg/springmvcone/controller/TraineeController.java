package com.cg.springmvcone.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcone.dto.Trainee;
import com.cg.springmvcone.service.ITraineeService;



@Controller
public class TraineeController {
	
	@Autowired
	ITraineeService traineeservice;
	
	//directing to addTrainee jsp
		@RequestMapping(value="add",method=RequestMethod.GET)
		public String addData(@ModelAttribute("my")Trainee trainee,Map<String,Object>model)
		{
			List<String> myList=new ArrayList<String>();
			myList.add("Java");
			myList.add("Testing");
			myList.add("Mainframe");
		    myList.add(".NET");
	
			model.put("ttype", myList);
			return "addTrainee";

}
		//add
		@RequestMapping(value="putData", method=RequestMethod.POST)
		public String dataAdd(@ModelAttribute("my") Trainee trainee)
		{
		traineeservice.insertData(trainee);
		return "redirect:/trainee.jsp";
	}
		/*
		//add
		@RequestMapping(value="putData",method=RequestMethod.POST)
		public  ModelAndView dataAdd(@ModelAttribute("my") Trainee trainee)
		{   
			int traineeId=traineeservice.insertData(trainee);
			System.out.println(trainee.getTraineeLocation());
			return new ModelAndView("success", "traine", traineeId);
		}
		  
		*/
		
		//SHOW
		@RequestMapping(value="retrieveall",method=RequestMethod.GET)
		public ModelAndView dataShow()
		{ List<Trainee> allData=traineeservice.ShowData();
			return new  ModelAndView("retrieveallTrainee","mydata",allData);
		}
		
		//directed to search jsp
		
		@RequestMapping(value="retrieve",method=RequestMethod.GET)
		public String searchPage(@ModelAttribute("data") Trainee tSearch)
		{
			return "retrieveTrainee";
			
		}
		//Retrieve/search 
		@RequestMapping(value="searchdata",method=RequestMethod.POST)
		public ModelAndView searchData(@ModelAttribute("data") Trainee tData)

		{
			//System.out.println(tData.getTraineeId());
			int traineeId=tData.getTraineeId();
			 List<Trainee> searchData=traineeservice.searchData(traineeId);
			return new  ModelAndView("retrieveallTrainee","mydata",searchData);
		}
		
		//directed to delete
	    @RequestMapping(value="delete", method=RequestMethod.GET)
		public String removePage(@ModelAttribute("Data") Trainee tRemove)
		{
			return "deleteTrainee";
			
		}
		//delete
		@RequestMapping(value="removeTrainee", method=RequestMethod.POST)
		public ModelAndView removeData(@ModelAttribute("Data") Trainee tData)
		{
			int traineeId= tData.getTraineeId();
           
			List<Trainee> deleteData=traineeservice.removeData(traineeId);
		
			return new ModelAndView("retrieveallTrainee","mydata", deleteData);
		
		}
		/*
		@RequestMapping(value="removedata", method=RequestMethod.POST)
		public ModelAndView removeData(@ModelAttribute("mysearch") Trainee tran)
		{
			int tranId = tran.getTraineeId();
			List<Trainee> deleteData=service.removeData(tranId);
			
			return new ModelAndView("show", "trainee", deleteData);
			
		}
		*/
		// directed to update jsp
		
		@RequestMapping(value="update", method=RequestMethod.GET)
		public String updateTrainee(@ModelAttribute("mysearch") Trainee trainee)
		{
			return "updateTrainee";
			
		}

		//searching trainee
		@RequestMapping(value="searchTrainee", method=RequestMethod.POST)
		public ModelAndView searchTrainee(@ModelAttribute("mysearch") Trainee trainee, Map<String,Object> model)
		{

			List<String> myList= new ArrayList<String>();
			
			myList.add("Java");
			myList.add("Testing");
			myList.add("Mainframe");
		    myList.add(".NET");
			
			model.put("ttype",myList);
		
			int traineeId = trainee.getTraineeId();
			List<Trainee> allData = traineeservice.searchData(traineeId);
			
			return new ModelAndView("Update", "mydata", allData);
			
		}
		//update
		@RequestMapping(value ="putdata" , method = RequestMethod.POST)
		public String updateData(@ModelAttribute("mysearch")Trainee trainee)
		
		{
			traineeservice.updateData(trainee);
			
			return "redirect:/trainee.jsp";
			
		}
		
}