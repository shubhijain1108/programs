package com.cg.springmvcone.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcone.dao.ITraineeDao;
import com.cg.springmvcone.dto.Trainee;

@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService{
	@Autowired
    ITraineeDao traineedao;
	@Override


	public int insertData(Trainee trainee) {
		// TODO Auto-generated method stub
		return traineedao.insertData(trainee);
	}

	@Override
	public List<Trainee> ShowData() {
		// TODO Auto-generated method stub
		return traineedao.ShowData();
	}

	
	@Override
	public List<Trainee> removeData(int traineeId) {
		return traineedao.removeData(traineeId);
		
	}

	@Override
	public List<Trainee> searchData(int traineeId) {
		// TODO Auto-generated method stub
 		return traineedao.searchData(traineeId);
	}

	@Override
	
	public void updateData(Trainee trainee) {
		// TODO Auto-generated method stub

		traineedao.updateData(trainee);
	}
	
}
